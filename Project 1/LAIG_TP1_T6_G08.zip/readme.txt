Class: 6
Group: 8
Students: Gon�alo Nuno Botelho Amaral Rol�o Bernardo, 201606058
	  Joana Sofia Mendes Ramos, 		      201605017